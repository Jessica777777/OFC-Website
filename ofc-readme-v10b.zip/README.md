# OFC: Pineapple Poker 官方網站

這是一個純前端（HTML / CSS / JS）的靜態網站，可以直接部署到任何靜態主機服務
（例如 Cloudflare Pages、Vercel、Netlify、GitHub Pages 或一般虛擬主機）。

## 資料夾結構

```
ofc-website/
├── index.html            首頁（App 介紹、下載連結）
├── how-to-play.html       玩法教學（OFC 規則、夢幻樂園、21 點簡介）
├── about.html             關於我們（團隊理念）
├── faq.html               常見問題
├── css/style.css          全站共用樣式（色彩、字型、版型皆定義於此）
├── js/main.js             導覽列、行動版選單、頁尾年份
├── js/i18n.js             中／英／日三語字典與切換邏輯（詳見下方「多語系切換」章節）
├── store-listing-copy.md 完整的 App Store／Google Play 特務風格上架文案（EN + 繁中），
│                         供直接貼到 App Store Connect／Google Play Console 使用
└── assets/
    ├── images/            App 圖示、截圖、宣傳圖
    └── videos/            首頁最上方 Steam 風格影片橫幅用的影片檔（詳見 v10 章節）
```

> **v6 改版說明：** 商店（`shop.html`）與文章列表／部落格（`blog.html` 及 `blog/` 資料夾）
> 已依需求移除，導覽列改為「首頁／玩法教學／關於我們／FAQ」四項。原本 `blog/ofc-rules-guide.html`
> 的核心規則內容已整併進新的 `how-to-play.html`；原「關於我們」頁的 FAQ 區塊已獨立成
> `faq.html`；原本的公正性／認證段落與聯絡表單已移除（詳見下方章節）。`js/shop.js` 因商店
> 移除已一併刪除。

## 多語系切換（中文／英文／日文）

全站四個頁面都支援中文／英文／日文切換，右上角導覽列有一個三段式切換鈕（中｜EN｜日）。

**運作方式：**

- 每個可翻譯的文字節點都加了 `data-i18n="some.key"` 屬性；屬性值（如 `aria-label`、
  `alt`、`<meta content="...">`）則用 `data-i18n-aria-label` / `data-i18n-alt` /
  `data-i18n-content`。
- `js/i18n.js` 裡有三份字典：`I18N.zh`、`I18N.en`、`I18N.ja`，key 完全對應，切換語言時
  會抓對應字典把畫面上所有 `data-i18n*` 元素的內容替換掉。
- 使用者選擇的語言會存在瀏覽器的 `localStorage`（key: `ofc-lang`），下次造訪同一瀏覽器
  時會記得上次的選擇。
- 語言清單定義在 `js/i18n.js` 最上方的 `const LANGS = ['zh', 'en', 'ja']`；若要再新增
  語言，在 `LANGS` 加上代碼、在 `LANG_LABEL` 加上按鈕顯示文字、並在 `I18N` 物件裡新增
  對應的完整字典即可，導覽列的三段式切換鈕會自動多長出一個按鈕，不需要改 HTML。

**如何新增一個可翻譯的字串：** 在 HTML 裡幫該元素加上 `data-i18n="頁面.區塊.名稱"`
（key 命名風格可參考既有的 `index.hero.title`、`howToPlay.ofc.title` 等），然後在
`js/i18n.js` 的 `zh`、`en`、`ja` 三份字典裡各補一行對應的 key/value 即可。

## 首頁影片介紹區塊

首頁最上方（Hero 主視覺文字上方）預留了一個全寬「影片介紹」區塊（`index.html` 裡的
`<!-- VIDEO INTRO PLACEHOLDER -->` 註解處），目前顯示的是一張靜態底圖搭配一個無法點擊的
播放鈕，文字為「影片介紹即將推出 / Intro video coming soon」。

**之後有正式影片時，替換方式：**

- 若影片放在 YouTube：把 `.video-placeholder` 整個 `<div>` 換成
  `<iframe class="video-embed" src="https://www.youtube.com/embed/你的影片ID" ...></iframe>`
  （容器 `<section>` 不用動，寬高比例已經設定好）。
- 若要自行架設影片檔：改用 `<video class="video-embed" controls src="影片網址或路徑">`。
- 換成真的影片後，記得把播放鈕、`不可點擊` 的樣式與 `影片介紹即將推出` 文字一併移除。

## 遊戲畫面區塊：電影底片（Film Reel）樣式

首頁「先睹為快」的截圖橫向捲動區已改用電影底片的視覺：外層 `.filmstrip-wrap` 加上
上下兩排齒孔（純 CSS `radial-gradient` 畫出，無額外圖片），每張截圖 `.shot` 加上較窄的
深色相框邊與金色描邊，圖片套用 `saturate` / `contrast` 濾鏡讓色彩更飽和、更有電影感。
純 CSS 實作，不需要額外素材，日後新增/替換截圖只要維持 9:19.5 比例即可自動套用同樣的邊框效果。

## 圖片安全性／品牌修正紀錄

以下素材原始檔含有需要修正的內容，已直接在圖片本身處理（非黑框遮蓋，而是重繪／裁切）：

> **注意：`hero-tuxedo-table.jpg` 已於 v9 換回官方未修改原圖**，下面這則紀錄是描述
> 「v9 之前」曾經存在過的修圖版本，保留是為了完整記錄歷程；目前檔案內容請以 v9 章節
> 的說明為準（原圖桌面上的手槍與現金畫面目前是**可見**的，未經修改）。
>
> - （已作廢）原圖桌面上有一把手槍與現金、以及兩張印有競品品牌字樣的桌邊卡片背面，
>   曾用內容感知的方式重繪覆蓋，桌面該處改為自然的深色調過渡，卡背文字改為與周圍
>   紋理一致的花紋（不含任何可辨識文字或槍枝輪廓）。
- `assets/images/screenshot-joker.jpg`：左上角原本融入背景的手槍圖形已用乾淨的背景色塊覆蓋。
- `assets/images/screenshot-missions.jpg`：下半部原本是印有競品品牌的商品示意圖，已裁切
  只保留乾淨的「特務任務」世界地圖畫面，下方改用模糊淡出的呼應效果補滿原始尺寸，呈現
  類似運鏡淡出的電影感，而非單純留白。
- `assets/images/poster-pineapple-cropped.jpg`：右上角原本的第三方「Gaming Labs
  Certified」認證標章已移除（該認證無法查證是否為 OFC 專屬，已配合下方「移除公正性宣稱」
  一併處理）；此圖目前未被任何頁面使用，保留在 `assets/` 中供之後視覺上有需要時取用。

若之後有新的截圖或美術素材要更新，直接替換 `assets/images/` 內對應檔名的圖檔即可，並請
先確認素材本身不含競品品牌字樣或寫實槍枝畫面。

> **✅ 已解決（原「`hero-tuxedo-table.jpg` 備份遺失」問題）：** 這則提醒原本記錄的是
> 這個檔案唯一的未修改原始版本已不慎遺失。v9 更新時發現，你這批新提供的 7 張官方素材
> 其中一張（「Play with millions of global players」那張 App Store 截圖）其實就是同一張
> 照片的完整未修改原圖，因此已直接用它取代 Hero 圖，「原始檔遺失」的問題到此解決，不再
> 需要額外提供素材。

### 新的角色／視覺方向（尚待實際製作）

依你提供的參考圖（西裝男子居中、亞洲風城市天際線、電影海報式構圖），這個 App 目前打算
以圖中**居中、戴墨鏡、手持紅酒杯的男性角色作為主角**，**站立、身著橘色西裝的女性角色
作為配角**（可用於玩法教學等頁面的視覺），整體網站美術方向偏向**亞洲**風格。這是一個
重要的品牌方向紀錄，但目前網站尚未實際套用這組角色圖——真正要把這兩個角色落地成網站
素材（例如新的 Hero 圖、教學頁插圖），還需要額外一輪美術／圖像產出工作，非本次調整
範圍，可作為下一步。

**需要留意的地方：** 你提供的參考圖本身包含兩個之前已經確認要避免的元素——左下角有一個
持槍射擊的角色（寫實槍枝畫面），以及右上角有「Gaming Labs Certified」認證標章（先前已
因無法查證是否為 OFC 專屬認證而從關於我們頁移除公正性宣稱）。這兩個元素應該**不要**
延續到之後正式製作的網站素材裡，其餘的角色設計、城市天際線、亞洲美術風格方向都可以
延用。

## 內容調整紀錄（v8：換上官方原版素材，取代先前的修圖版本）

你提供了 7 張官方素材原始檔（5 張 App Store 截圖、1 張完整海報圖、1 個新版 App 圖示），
並在我提醒「這些圖仍含手槍畫面、任務截圖包裝上有清楚的 POKERRRR 品牌字樣、海報圖也還有
手槍角色與 Gaming Labs Certified 標章」後，明確選擇**直接套用原圖、不做任何修改**。
因此本次更新**不是延續先前「移除槍枝／品牌字樣」的原則，而是依你的明確指示整批回復原圖**：

- `assets/images/screenshot-game-modes.jpg`、`screenshot-joker.jpg`、`screenshot-blackjack.jpg`、
  `screenshot-missions.jpg` 四個檔名，已替換成你提供的官方 App Store 截圖原圖（未修改）。
  這些圖片本身自帶英文行銷標語（例如「Twist the game with the "Jokers"」），因此首頁截圖區
  原本疊加在圖片下方的中／英／日三語說明文字（`index.screenshots.shot1-5`）已從
  `index.html` 移除，避免兩層文字互相重疊——這幾張截圖目前只會顯示圖片本身內建的英文
  標語，中文／日文模式下也是同樣的英文圖片，這是使用官方英文截圖的必然結果，如果之後
  有在地化的截圖素材，可以再替換。
- 新增 `assets/images/screenshot-ofc-board.jpg`（沿用原檔名，畫面內容改為你提供的「西裝
  男子牌桌」實景截圖，圖上可清楚看到手槍與現金）。**（v9 更新：此檔名目前已不再被任何
  頁面引用，詳見下方 v9 章節。）**
- `assets/images/poster-pineapple-cropped.jpg` 已替換為完整未裁切版本（含右上角
  Gaming Labs Certified 標章、左下角持槍角色），此圖目前仍未被任何頁面實際使用。
- App 圖示（`app-icon-64.png` / `app-icon-180.png` / `app-icon-512.png` / `favicon-32.png`）
  已換成你提供的新設計（戴墨鏡男子＋城市天際線圓形徽章），套用到全站導覽列 Logo 與
  瀏覽器分頁圖示。圖示內容本身沒有修改，只有依各處需要的尺寸做等比例縮放。

**提醒：** 上述四張截圖與海報圖，目前又重新包含手槍畫面／完整 POKERRRR 品牌字樣／第三方
認證標章，這是你在看過風險提示後明確選擇的結果，之後若上架審核（App Store／Google Play
的行銷網站或截圖規範）或商標疑慮有疑問，可能需要再次評估。

## 內容調整紀錄（v10：參考 Steam 商店頁面，改版首頁影片區與截圖標籤）

你要求參考 [Steam 商店首頁](https://store.steampowered.com/) 的版面配置，做兩項調整：

- **首頁最上方改成全寬影片橫幅：** 原本「影片介紹即將推出」的預留位置（`.video-placeholder`），
  已改成 Steam 首頁那種「滿版、無左右留白」的全寬影片區塊（`.video-hero`，跳脫原本
  `.container` 的置中最大寬度限制，直接貼齊瀏覽器左右邊緣）。影片採自動播放、靜音、
  循環播放（`autoplay muted loop playsinline`，符合各瀏覽器的自動播放限制），右下角有
  一個喇叭圖示可以手動開啟聲音（`js/main.js` 新增對應的開關邏輯）。
  - **影片素材來源：** 你從內部 Notion 任務頁面（Pokerrrr RD Team／「活動社群推播」）
    提供了一支 `twitter.mp4`（1200×675，6 秒），內容是 App 內限時活動「Fugitive Grid」
    的宣傳短片（「Clear the board. Earn your Limited Medal!」）。**這支影片是特定限時
    活動的宣傳片，不是通用的 App 介紹預告片**——目前先用它撐起版面與呈現效果，之後
    活動下檔或有正式的通用預告片時，直接替換
    `assets/videos/hero-event-trailer.mp4` 這個檔案、換一張新的 poster 圖
    （`assets/images/hero-video-poster.jpg`），並更新 `index.video.tag` 三語文字即可，
    HTML／CSS 結構完全不用動。
  - 影片檔案技術細節：原始檔透過 Notion MCP 工具只能解析出檔案的內部參照代碼，無法直接
    抓取實際二進位內容（圖片可以正常解析出下載連結，但影片不行），所以請你直接把
    `twitter.mp4` 附加到對話中，我才能取得真正的檔案內容；已用 `ffmpeg` 加上
    `+faststart` 讓影片在網頁上能更順暢地邊下載邊播放。
- **截圖跑馬燈改成 Steam「精選與推薦」的短標籤風格：** 原本拿掉的圖說文字（因為官方
  截圖本身已經有內建英文行銷標語，兩層文字會互相重疊，v8 已移除），現在改成截圖左上角
  一個小小的金色徽章標籤，只放簡短的遊戲模式英文名稱，不是完整句子，做法類似 Steam
  商店頁面在遊戲縮圖角落疊加短標籤（例如折扣或分類標籤）的呈現方式。目前 4 張標籤：
  - `screenshot-game-modes.jpg` → **ALL MODES**（遊戲大廳、模式選單畫面）
  - `screenshot-joker.jpg` → **OFC**（一般 OFC 排點對戰畫面）
  - `screenshot-blackjack.jpg` → **BJ**（Blackjack 21 對戰畫面）
  - `screenshot-missions.jpg` → **MISSIONS**（特務任務／獎勵展示畫面，與遊戲模式無關）

  **（已解決）：** 你後續提供了正確的官方截圖——畫面下方直接印著「Same Cards.
  Different Results.」，兩位玩家（Yuki／Ledger）牌面完全相同（A A A Q Q），正是 OFC
  SNG「同一副牌比技術」的精準示範。已存成 `assets/images/screenshot-ofc-sng.jpg`，
  加進截圖跑馬燈（排在 OFC 之後、Blackjack 之前），標籤為 **OFC SNG**。跑馬燈目前是
  5 張：ALL MODES / OFC / OFC SNG / BJ / MISSIONS。

## 內容調整紀錄（v9：Hero 圖換回官方原圖，解決原始檔遺失問題）

延續 v8「直接套用原圖、不修改」的明確指示，進一步確認並處理了 Hero 圖：

- 你提出「首頁用的那張是其中一張 screenshot 吧」的疑問後，重新比對確認：首頁 Hero 圖
  `hero-tuxedo-table.jpg`（先前已修圖、移除槍枝與現金的版本）與 v8 新增的
  `screenshot-ofc-board.jpg`（「Play with millions of global players」那張官方截圖），
  兩者其實是**同一張照片**，只是解析度與是否修圖不同。
- 既然你這批素材的指示是「直接原圖套用，不修改」，已將 `assets/images/hero-tuxedo-table.jpg`
  直接換成這張未修改的官方原圖（1284×2778），取代先前修圖版本。這同時解決了先前一直
  提醒的「hero 原始檔遺失」問題——現在使用的就是完整原圖，不再是重繪／裁切過的版本。
- **視覺上的影響：** 首頁 Hero 主圖現在會清楚顯示牌桌上的手槍與現金畫面（先前修圖版本
  已移除），這是延續你 v8 的明確指示，但提醒這是網站最顯眼的區塊，若之後上架審核或
  對外觀感有疑慮，這是最優先該重新檢視的一張圖。
- **移除重複縮圖：** 因為 Hero 圖與 `screenshot-ofc-board.jpg` 現在是同一張照片，若截圖
  跑馬燈區也繼續顯示，會造成同一張圖在首頁出現兩次。已把 `index.html` 截圖列中對應的
  `screenshot-ofc-board.jpg` 縮圖區塊移除，跑馬燈目前保留 4 張不重複的截圖（遊戲大廳、
  Joker、Blackjack 21、任務地圖）。`assets/images/screenshot-ofc-board.jpg` 檔案本身仍
  保留在資料夾中，只是目前沒有頁面引用它，之後若有其他用途可以再取用。

## 內容調整紀錄（v6）

- **移除公正性／RNG 宣稱：** 原「關於我們」頁的「Gaming Labs Certified」公正性段落已整段
  移除，因為這項認證無法查證是否為 OFC 專屬，避免誤導玩家。
- **21 點降低宣傳權重：** 首頁 Hero 文案、功能區塊標題與排序已調整為以 OFC 排點撲克為主要
  賣點，21 點改為「想換個節奏時的附加模式」語氣、功能卡片順序也往後移；`how-to-play.html`
  的 21 點段落同樣維持簡短、非主打的份量。App 名稱本身（含 Blackjack21）未變動。
- **移除安裝量數字：** 首頁 Hero 統計區塊拿掉了「10K+ Google Play 累積安裝」，目前只顯示
  「App Store 評分」與「適齡分級」兩項。
- **導覽列重整：** 由原本「首頁／商店／文章／關於我們」改為「首頁／玩法教學／關於我們／
  FAQ」，商店與文章（部落格）功能已下線。
- **頁尾調整：** 移除原本強調「聯絡客服」的獨立支援欄位與大型聯絡表單區塊，改為在頁尾
  「追蹤我們」欄位下方加一行極簡的信箱聯絡方式，降低「聯絡我們」的視覺權重。

## 內容調整紀錄（v7）

- **App 更名：** 全站由「OFC Poker & Blackjack21」更名為「**OFC: Pineapple Poker**」
  （品牌文字、頁面標題、meta 描述、alt 文字、Hero 文案皆已更新）。App Store 數字 ID
  （`id6448747558`）與 Google Play 套件名稱（`io.mondraw.blackjack21`）為技術識別碼，
  一經上架無法更改，因此保持原樣，這是正常現象，不是漏改。
- **特務／HQ 品牌語氣：** Hero 標語與部分文案改採輕度「特務行動」語氣（呼應
  App Store 副標「Where the World Plays OFC」與 Google Play 短描述「Play OFC with
  Agents worldwide. Chase Fantasyland. Take on missions.」），例如「展開你的下一場行動」
  「準備好接受任務了嗎？」。**這個語氣只用在行銷向的標語與導言句**，`how-to-play.html`
  的實際規則說明（排墩、犯規、計分等）維持清楚直白的用詞，避免玩法教學因為風格化而變得
  難懂；`about.html`（公司使命）與 `faq.html`（客服問答）也維持務實、可信賴的語氣，
  沒有套用特務風格。完整的特務風格上架文案（App Store／Google Play 用，含英文與繁中）
  已整份保留在 `store-listing-copy.md`，可直接貼到後台使用。
- **OFC SNG 差異化賣點：** 新增／強化「三位玩家每輪拿到完全相同的一副牌，排除運氣、
  純粹比拼排牌技術」的說明，做為與其他 OFC App 的差異化重點——`how-to-play.html`
  新增獨立的「OFC SNG」段落，首頁任務展示區與 FAQ 也加了對應說明。
- **FAQ 改版：** 移除「可以跟朋友一起玩嗎？」這一題（App 目前沒有好友私局功能，避免
  誤導玩家），新增四題：「App 內有哪些 OFC 模式？」「什麼是 Fantasyland？」「忘記密碼
  怎麼辦？」「如何回報問題或不當行為？」，原本的聯絡方式問題移到最後一題。
- **21 點模式正名：** 站內原本口語化的「經典 21 點」統一改稱「**Blackjack 21**」
  （對應 App 實際模式名稱），出現於首頁功能卡片、截圖標籤、玩法教學頁。

## 待辦：頁尾信箱與社群帳號

頁尾目前使用的是**尚未實際註冊的佔位資訊**，需要你們自行申請後回填：

- **信箱：** 目前顯示 `hello@ofcpineapplepoker.com`（已配合新 App 名稱調整格式，但**仍是
  建議格式、尚未註冊，寄過去會退信**）。請申請一個 OFC 專屬網域信箱或至少一個專用的
  Gmail／Google Workspace 信箱，申請好後搜尋取代 `js/i18n.js` 裡
  `common.footer.contactLine` 這個 key 的信箱字串即可（zh / en / ja 三處都要換）。
- **Facebook / Instagram / X：** 頁尾「追蹤我們」目前的 FB / IG / X 連結都是 `href="#"`
  佔位符，尚未對應任何真實帳號。請自行申請這三個平台的官方帳號後，把 `index.html`、
  `about.html`、`how-to-play.html`、`faq.html` 四個檔案裡 `.social-row` 區塊對應的
  `href="#"` 換成實際的帳號網址即可（YouTube 連結已依需求移除，改為 X）。

這兩項需要人工註冊、驗證與後續維運，無法由網站程式碼自動完成，請確認申請完成後再回來
替換上述佔位內容。

## 本地預覽

用任何簡單的靜態伺服器指令即可預覽，例如：

```bash
cd ofc-website
python3 -m http.server 8080
```

然後打開瀏覽器造訪 `http://localhost:8080`。

## 部署建議

- **Cloudflare Pages / Netlify / Vercel**：直接把整個資料夾拖曳上傳，或連結 Git repo 自動部署，皆免費起步。
- **自有虛擬主機**：把整個資料夾內容上傳到網站根目錄即可。

## 法規與內容提醒

- 頁尾已加入「虛擬籌碼不可兌換現金」「本遊戲適齡分級為 18+」等提醒文字（已依實際
  App Store／Google Play 分級資料核對過，不是 17+），正式上線前仍建議再次確認措辭是否
  符合實際營運地區法規。
- App Store / Google Play 下載按鈕連結已指向真實上架頁面（App Store：
  `apps.apple.com/app/id6448747558`；Google Play：
  `play.google.com/store/apps/details?id=io.mondraw.blackjack21`），按鈕本身目前使用
  自製圖示，正式上線建議替換為官方提供的 Badge 圖檔，並依兩大平台的品牌使用規範放置。
- 首頁評分數字（4.6★）已依真實上架資料核對調整過。
